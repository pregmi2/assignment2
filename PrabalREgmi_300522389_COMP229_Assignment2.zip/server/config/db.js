module.exports = 
{
    //"URI": "mongodb://localhost/businesscontact"
    "URI": "mongodb+srv://pregmi2:T3ACECmsRtuuCu7e@cluster0.rw8tr.mongodb.net/ContactInfo?retryWrites=true&w=majority"
}